import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.widgets import RadioButtons, CheckButtons, Button
import heapq
import serial
import time


class SimuladorEurobot:
    def __init__(self):
        self.ancho_tablero = 3000
        self.alto_tablero = 2000

        self.inicio_x = 2885.0
        self.inicio_y = 1785.0

        self.robot_x = self.inicio_x
        self.robot_y = self.inicio_y
        self.robot_theta = 270.0

        self.radio_robot = 60
        self.ruta_completa = []

        self.max_tramo_mm = 500.0
        self.factor_avance = 0.88

        self.factor_giro = 1.00
        self.factor_giro_almacen_1 = 1.05
        self.factor_giro_almacen_8 = 0.65

        self.restar_giro_almacen_4_inicio_grados = 5.0
        self.restar_giro_almacen_5_inicio_grados = 1.5
        self.restar_giro_almacen_6_inicio_grados = 1.0

        # Almacén 7 desde inicio.
        # Más valor  -> gira menos
        # Menos valor -> gira más
        # Ahora está en -3.0 para que el primer giro gire un poco más.
        self.restar_giro_almacen_7_inicio_grados = -3.0

        # Giro suave para el primer giro del almacén 7 desde inicio.
        self.primer_giro_almacen_7_hecho = False
        self.max_giro_suave_almacen_7_grados = 30.0
        self.pausa_giro_suave_almacen_7_s = 0.20

        # Ajuste final del almacén 7 desde inicio.
        # Último giro a la inversa.
        self.giro_final_izquierda_almacen_7_inicio_grados = -15.0
        self.avance_final_almacen_7_inicio_mm = 100.0
        self.ajuste_final_almacen_7_hecho = False

        self.factor_giro_almacen_9_inicio = 0.85
        self.restar_giro_almacen_10_inicio_grados = 10.0

        self.factor_ultima_interaccion_almacen_2 = 0.50

        self.factor_ultima_interaccion_antes_giro_almacen_4_inicio = 0.5625
        self.retroceso_final_almacen_4_inicio_mm = 50.0
        self.ruta_almacen_4_desde_inicio = False

        self.ruta_almacen_5_desde_inicio = False
        self.factor_ultima_interaccion_antes_giro_almacen_5_inicio = 0.75
        self.factor_ultima_interaccion_almacen_5_inicio = 0.75
        self.retroceso_final_almacen_5_inicio_mm = 50.0

        self.ruta_almacen_6_desde_inicio = False
        self.factor_ultima_interaccion_antes_giro_almacen_6_inicio = 0.75
        self.factor_ultima_interaccion_almacen_6_inicio = 0.50

        self.ruta_almacen_7_desde_inicio = False
        self.factor_ultima_interaccion_antes_giro_almacen_7_inicio = 0.75

        self.ruta_almacen_9_desde_inicio = False
        self.factor_ultima_interaccion_despues_giro_almacen_9_inicio = 0.75

        self.ruta_almacen_10_desde_inicio = False
        self.factor_ultima_interaccion_almacen_10_inicio = 0.3125

        self.retroceso_final_almacen_1_mm = 120.0

        self.giro_final_inverso_almacen_3_grados = 10.0
        self.retroceso_final_almacen_3_mm = 100.0

        self.maniobra_primer_giro_almacen_3_hecha = False
        self.retroceso_primer_giro_almacen_3_mm = 80.0
        self.giro_derecha_primer_giro_almacen_3_grados = 6.0

        self.avance_final_almacen_8_mm = 15.0
        self.quitar_interacciones_almacen_8 = 1
        self.interacciones_despues_giro_almacen_8 = 1.75
        self.contador_avances_almacen_8 = 0

        self.ruta_especial_3_a_4 = False
        self.factor_avance_3_a_4 = 0.88

        # Termómetro rápido
        self.modo_termometro = False
        self.giro_inicial_izquierda_termometro_grados = 5.5
        self.avance_largo_termometro_mm = 1550.0
        self.giro_final_termometro_grados = -90.0
        self.avance_final_termometro_mm = 390.0

        self.ultimo_giro_enviado = 0.0
        self.ultimo_almacen_visitado = None

        self.zona_roja = [600, 1600, 1800, 400, "ZONA ROJA PRINCIPAL"]

        self.almacenes = {
            "1": {"rect": [1650, 1350, 200, 200], "ocupado": False},
            "2": {"rect": [1150, 1350, 200, 200], "ocupado": False},
            "3": {"rect": [2800, 700, 200, 200], "ocupado": False},
            "4": {"rect": [2100, 700, 200, 200], "ocupado": False},
            "5": {"rect": [1400, 700, 200, 200], "ocupado": False},
            "6": {"rect": [700, 700, 200, 200], "ocupado": False},
            "7": {"rect": [0, 700, 200, 200], "ocupado": False},
            "8": {"rect": [2200, 0, 200, 200], "ocupado": False},
            "9": {"rect": [1400, 0, 200, 200], "ocupado": False},
            "10": {"rect": [600, 0, 200, 200], "ocupado": False}
        }

        self.almacen_destino_actual = "1"

        # Cambia este puerto por el COM real de tu Arduino.
        self.puerto_arduino = "COM12"

        self.arduino = self.conectar_arduino_robot()

        try:
            self.img_fondo = plt.imread("tablero.jpg")
        except FileNotFoundError:
            print("AVISO: No se ha encontrado 'tablero.jpg'. Se usará fondo blanco.")
            self.img_fondo = None

        self.fig, self.ax = plt.subplots(figsize=(14, 8))
        plt.subplots_adjust(left=0.05, right=0.75, top=0.86, bottom=0.05)

        self.fig.canvas.mpl_connect("close_event", self.al_cerrar_ventana)

        self.crear_interfaz()
        self.configurar_mapa()
        self.dibujar_robot()

    def conectar_arduino_robot(self):
        baudrate = 115200
        timeout_lectura = 8
        timeout_escritura = 8

        puerto = self.puerto_arduino

        ciclos_busqueda = 120
        espera_entre_intentos = 10
        espera_despues_de_abrir = 10

        print("[SISTEMA] Conectando Arduino principal del robot.")
        print(f"[SISTEMA] Puerto robot configurado: {puerto}")

        for intento in range(1, ciclos_busqueda + 1):
            try:
                print(f"\n[SISTEMA] Intento robot {intento}/{ciclos_busqueda}")
                print(f"[SISTEMA] Abriendo {puerto}...")

                arduino = serial.Serial(
                    port=puerto,
                    baudrate=baudrate,
                    timeout=timeout_lectura,
                    write_timeout=timeout_escritura,
                    dsrdtr=False,
                    rtscts=False
                )

                print(f"[SISTEMA] Puerto robot {puerto} abierto.")
                print(f"[SISTEMA] Esperando {espera_despues_de_abrir} s para estabilizar conexión...")

                time.sleep(espera_despues_de_abrir)

                arduino.reset_input_buffer()
                arduino.reset_output_buffer()

                print(f"[SISTEMA] Robot conectado en {puerto}")
                return arduino

            except Exception as e:
                print(f"[SISTEMA] No se ha podido abrir el puerto robot {puerto}: {e}")

                try:
                    if "arduino" in locals() and arduino is not None and arduino.is_open:
                        arduino.close()
                except Exception:
                    pass

                print(f"[SISTEMA] Esperando {espera_entre_intentos} s antes de reintentar...")
                time.sleep(espera_entre_intentos)

        print("\nADVERTENCIA: No se ha podido conectar con el Arduino principal.")
        print("El simulador funcionará en modo solo visual para el robot.")
        return None

    def al_cerrar_ventana(self, event):
        if self.arduino is not None and self.arduino.is_open:
            print("\n[SISTEMA] Cerrando puerto del robot...")
            self.arduino.close()
            print("[SISTEMA] Puerto robot liberado.")

    def crear_interfaz(self):
        nombres_almacenes = list(self.almacenes.keys())

        ax_btn_reset_pos = plt.axes([0.05, 0.91, 0.14, 0.055])
        self.btn_reset_pos = Button(ax_btn_reset_pos, "RESET POS", color="lightcoral", hovercolor="red")
        self.btn_reset_pos.on_clicked(self.reset_pos)

        ax_btn_inicio = plt.axes([0.21, 0.91, 0.18, 0.055])
        self.btn_inicio = Button(ax_btn_inicio, "VOLVER A INICIO", color="lightblue", hovercolor="deepskyblue")
        self.btn_inicio.on_clicked(self.volver_inicio)

        ax_btn_termometro = plt.axes([0.41, 0.91, 0.16, 0.055])
        self.btn_termometro = Button(ax_btn_termometro, "TERMÓMETRO", color="orange", hovercolor="darkorange")
        self.btn_termometro.on_clicked(self.ejecutar_termometro)

        ax_btn_celebrar = plt.axes([0.59, 0.91, 0.14, 0.055])
        self.btn_celebrar = Button(ax_btn_celebrar, "CELEBRAR", color="violet", hovercolor="plum")
        self.btn_celebrar.on_clicked(self.ejecutar_celebrar)

        ax_radio = plt.axes([0.78, 0.38, 0.2, 0.43])
        ax_radio.set_title("1. Elegir Destino")
        self.radio_destino = RadioButtons(ax_radio, nombres_almacenes)
        self.radio_destino.on_clicked(self.seleccionar_destino)

        ax_btn_ir = plt.axes([0.78, 0.88, 0.2, 0.06])
        self.btn_ir = Button(ax_btn_ir, "¡IR AL ALMACÉN!", color="lightgreen", hovercolor="lime")
        self.btn_ir.on_clicked(self.ejecutar_ruta_almacen)

        ax_check = plt.axes([0.78, 0.02, 0.2, 0.33])
        ax_check.set_title("2. Almacenes Ocupados")

        estados_iniciales = [False] * len(nombres_almacenes)
        self.check_ocupados = CheckButtons(ax_check, nombres_almacenes, estados_iniciales)
        self.check_ocupados.on_clicked(self.alternar_ocupacion)

    def reset_pos(self, event):
        print("\n[RESET POS] Reseteando posición lógica del robot a inicio")

        self.robot_x = self.inicio_x
        self.robot_y = self.inicio_y
        self.robot_theta = 270.0

        self.ruta_completa = []
        self.ultimo_giro_enviado = 0.0
        self.ultimo_almacen_visitado = None

        self.ruta_especial_3_a_4 = False
        self.ruta_almacen_4_desde_inicio = False
        self.ruta_almacen_5_desde_inicio = False
        self.ruta_almacen_6_desde_inicio = False
        self.ruta_almacen_7_desde_inicio = False
        self.ruta_almacen_9_desde_inicio = False
        self.ruta_almacen_10_desde_inicio = False
        self.modo_termometro = False
        self.maniobra_primer_giro_almacen_3_hecha = False
        self.contador_avances_almacen_8 = 0
        self.ajuste_final_almacen_7_hecho = False
        self.primer_giro_almacen_7_hecho = False

        if self.arduino is not None and self.arduino.is_open:
            try:
                self.arduino.reset_input_buffer()
                self.arduino.reset_output_buffer()
                print("[RESET POS] Buffers robot limpiados.")
            except Exception as e:
                print(f"[RESET POS] No se pudieron limpiar buffers robot: {e}")

        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()
        plt.pause(0.01)

        print(f"[RESET POS] Posición actual: x={self.robot_x:.0f}, y={self.robot_y:.0f}, theta={self.robot_theta:.0f}")

    def seleccionar_destino(self, label):
        self.almacen_destino_actual = label

    def alternar_ocupacion(self, label):
        self.almacenes[label]["ocupado"] = not self.almacenes[label]["ocupado"]
        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()

    def volver_inicio(self, event):
        print(f"\n[COMANDO] Volviendo a base: ({self.inicio_x:.0f}, {self.inicio_y:.0f})")

        self.ruta_especial_3_a_4 = False
        self.ruta_almacen_4_desde_inicio = False
        self.ruta_almacen_5_desde_inicio = False
        self.ruta_almacen_6_desde_inicio = False
        self.ruta_almacen_7_desde_inicio = False
        self.ruta_almacen_9_desde_inicio = False
        self.ruta_almacen_10_desde_inicio = False
        self.modo_termometro = False
        self.ajuste_final_almacen_7_hecho = False
        self.primer_giro_almacen_7_hecho = False

        self.ruta_completa = self.calcular_ruta(
            (self.robot_x, self.robot_y),
            (self.inicio_x, self.inicio_y)
        )

        if len(self.ruta_completa) > 0:
            self.animar_movimiento()

    def obtener_centro_almacen(self, rect):
        centro_x = rect[0] + rect[2] / 2
        centro_y = rect[1] + rect[3] / 2
        return centro_x, centro_y

    def ejecutar_ruta_almacen(self, event):
        almacen = self.almacenes[self.almacen_destino_actual]

        if almacen["ocupado"]:
            print(f"ERROR: El almacén {self.almacen_destino_actual} está ocupado.")
            return

        rect = almacen["rect"]
        dest_x, dest_y = self.obtener_centro_almacen(rect)

        print(f"\n[COMANDO] Iniciando ruta hacia almacén {self.almacen_destino_actual}: ({dest_x:.0f}, {dest_y:.0f})")

        self.ultimo_giro_enviado = 0.0
        self.maniobra_primer_giro_almacen_3_hecha = False
        self.contador_avances_almacen_8 = 0
        self.ruta_especial_3_a_4 = False
        self.ruta_almacen_4_desde_inicio = False
        self.ruta_almacen_5_desde_inicio = False
        self.ruta_almacen_6_desde_inicio = False
        self.ruta_almacen_7_desde_inicio = False
        self.ruta_almacen_9_desde_inicio = False
        self.ruta_almacen_10_desde_inicio = False
        self.modo_termometro = False
        self.ajuste_final_almacen_7_hecho = False
        self.primer_giro_almacen_7_hecho = False

        if self.ultimo_almacen_visitado == "3" and self.almacen_destino_actual == "4":
            print("[RUTA ESPECIAL] De almacén 3 a almacén 4: girar 90º a la derecha e ir recto.")
            self.ruta_especial_3_a_4 = True
            self.ruta_completa = [
                (self.robot_x, self.robot_y),
                (dest_x, dest_y)
            ]
        else:
            if self.almacen_destino_actual == "4" and self.ultimo_almacen_visitado is None:
                self.ruta_almacen_4_desde_inicio = True

            if self.almacen_destino_actual == "5" and self.ultimo_almacen_visitado is None:
                print("[AJUSTE ALMACÉN 5] Ruta desde inicio.")
                self.ruta_almacen_5_desde_inicio = True

            if self.almacen_destino_actual == "6" and self.ultimo_almacen_visitado is None:
                print("[AJUSTE ALMACÉN 6] Ruta desde inicio.")
                self.ruta_almacen_6_desde_inicio = True

            if self.almacen_destino_actual == "7" and self.ultimo_almacen_visitado is None:
                print("[AJUSTE ALMACÉN 7] Ruta desde inicio: primer giro suavizado y aumentado.")
                self.ruta_almacen_7_desde_inicio = True

            if self.almacen_destino_actual == "9" and self.ultimo_almacen_visitado is None:
                self.ruta_almacen_9_desde_inicio = True

            if self.almacen_destino_actual == "10" and self.ultimo_almacen_visitado is None:
                self.ruta_almacen_10_desde_inicio = True

            self.ruta_completa = self.calcular_ruta(
                (self.robot_x, self.robot_y),
                (dest_x, dest_y)
            )

        if len(self.ruta_completa) > 0:
            self.animar_movimiento()

    def ejecutar_termometro(self, event):
        print("\n[COMANDO] Ejecutando función TERMÓMETRO RÁPIDO")
        print("[TERMÓMETRO] Secuencia simplificada para intentar bajar de 15 segundos.")

        self.modo_termometro = True
        self.ruta_completa = []

        self.robot_x = self.inicio_x
        self.robot_y = self.inicio_y
        self.robot_theta = 270.0

        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()
        plt.pause(0.01)

        if self.arduino is not None and self.arduino.is_open:
            self.arduino.reset_input_buffer()
            self.arduino.reset_output_buffer()

        inicio_tiempo = time.time()

        print(f"[TERMÓMETRO] Giro inicial: {self.giro_inicial_izquierda_termometro_grados:.1f} grados")
        self.enviar_comando_arduino(f"<G:{self.giro_inicial_izquierda_termometro_grados:.1f}>")

        self.robot_theta += self.giro_inicial_izquierda_termometro_grados
        self.robot_theta = self.robot_theta % 360

        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()
        plt.pause(0.01)

        print(f"[TERMÓMETRO] Avance largo: {self.avance_largo_termometro_mm:.1f} mm")
        self.enviar_comando_arduino(f"<A:{self.avance_largo_termometro_mm:.1f}>")
        self.actualizar_visual_avance(self.avance_largo_termometro_mm)

        print(f"[TERMÓMETRO] Giro final: {self.giro_final_termometro_grados:.1f} grados")
        self.enviar_comando_arduino(f"<G:{self.giro_final_termometro_grados:.1f}>")

        self.robot_theta += self.giro_final_termometro_grados
        self.robot_theta = self.robot_theta % 360

        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()
        plt.pause(0.01)

        print(f"[TERMÓMETRO] Avance final: {self.avance_final_termometro_mm:.1f} mm")
        self.enviar_comando_arduino(f"<A:{self.avance_final_termometro_mm:.1f}>")
        self.actualizar_visual_avance(self.avance_final_termometro_mm)

        tiempo_total = time.time() - inicio_tiempo

        print(f"[TERMÓMETRO] Tiempo total aproximado: {tiempo_total:.2f} s")

        self.modo_termometro = False

        self.mover_servo_fin_tarea()

        print("[ESTADO] Función TERMÓMETRO completada")

    def ejecutar_celebrar(self, event):
        print("\n[COMANDO] Ejecutando función CELEBRAR")
        print("[CELEBRAR] Mandando comando C al Arduino principal.")

        self.enviar_comando_servo("C")

        print("[ESTADO] Celebración completada")

    def mover_servo_fin_tarea(self):
        print("[SERVO] Movimiento corto de fin de tarea")
        print("[SERVO] Mandando comando C al Arduino principal.")

        self.enviar_comando_servo("C")

    def configurar_mapa(self):
        self.ax.clear()

        self.ax.set_xlim(self.ancho_tablero, 0)
        self.ax.set_ylim(self.alto_tablero, 0)

        if self.img_fondo is not None:
            self.ax.imshow(
                self.img_fondo,
                extent=[self.ancho_tablero, 0, self.alto_tablero, 0]
            )

        self.ax.set_aspect("equal")

        rect_rojo = patches.Rectangle(
            (self.zona_roja[0], self.zona_roja[1]),
            self.zona_roja[2],
            self.zona_roja[3],
            linewidth=2,
            edgecolor="darkred",
            facecolor="red",
            alpha=0.5
        )

        self.ax.add_patch(rect_rojo)

        for nombre, datos in self.almacenes.items():
            r = datos["rect"]

            color_borde = "red" if datos["ocupado"] else "green"
            color_fondo = "red" if datos["ocupado"] else "lightgreen"
            alpha_val = 0.6 if datos["ocupado"] else 0.3

            rect = patches.Rectangle(
                (r[0], r[1]),
                r[2],
                r[3],
                linewidth=2,
                edgecolor=color_borde,
                facecolor=color_fondo,
                alpha=alpha_val
            )

            self.ax.add_patch(rect)

            self.ax.text(
                r[0] + r[2] / 2,
                r[1] + r[3] / 2,
                nombre,
                color="black",
                ha="center",
                va="center",
                fontsize=7,
                weight="bold"
            )

            cx, cy = self.obtener_centro_almacen(r)
            self.ax.plot(cx, cy, "ko", markersize=4)

    def dibujar_robot(self):
        cuerpo = patches.Circle(
            (self.robot_x, self.robot_y),
            self.radio_robot,
            linewidth=2,
            edgecolor="blue",
            facecolor="skyblue",
            alpha=0.9
        )

        self.ax.add_patch(cuerpo)

        extremo_x = self.robot_x + self.radio_robot * np.cos(np.radians(self.robot_theta))
        extremo_y = self.robot_y + self.radio_robot * np.sin(np.radians(self.robot_theta))

        self.ax.plot(
            [self.robot_x, extremo_x],
            [self.robot_y, extremo_y],
            color="black",
            linewidth=3
        )

        if len(self.ruta_completa) > 0:
            rx, ry = zip(*self.ruta_completa)
            self.ax.plot(rx, ry, "g-", linewidth=3)

    def es_valido(self, x, y):
        if x < 0 or x > self.ancho_tablero or y < 0 or y > self.alto_tablero:
            return False

        margen = self.radio_robot + 50
        z = self.zona_roja

        if (z[0] - margen) <= x <= (z[0] + z[2] + margen) and \
           (z[1] - margen) <= y <= (z[1] + z[3] + margen):
            return False

        for nombre, datos in self.almacenes.items():
            if datos["ocupado"]:
                r = datos["rect"]

                if (r[0] - margen) <= x <= (r[0] + r[2] + margen) and \
                   (r[1] - margen) <= y <= (r[1] + r[3] + margen):
                    return False

        return True

    def hay_linea_libre(self, p1, p2):
        x1, y1 = p1
        x2, y2 = p2

        distancia = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)

        if distancia == 0:
            return True

        paso_comprobacion = 10.0
        num_puntos = max(2, int(np.ceil(distancia / paso_comprobacion)))

        for i in range(num_puntos + 1):
            t = i / num_puntos
            x = x1 + (x2 - x1) * t
            y = y1 + (y2 - y1) * t

            if not self.es_valido(x, y):
                return False

        return True

    def calcular_ruta_l(self, start, goal):
        sx, sy = start
        gx, gy = goal

        esquina_1 = (sx, gy)
        ruta_1 = [start, esquina_1, goal]

        esquina_2 = (gx, sy)
        ruta_2 = [start, esquina_2, goal]

        rutas_validas = []

        if self.es_valido(esquina_1[0], esquina_1[1]):
            if self.hay_linea_libre(start, esquina_1) and self.hay_linea_libre(esquina_1, goal):
                distancia_1 = self.longitud_ruta(ruta_1)
                rutas_validas.append((distancia_1 * 0.8, ruta_1))

        if self.es_valido(esquina_2[0], esquina_2[1]):
            if self.hay_linea_libre(start, esquina_2) and self.hay_linea_libre(esquina_2, goal):
                distancia_2 = self.longitud_ruta(ruta_2)
                rutas_validas.append((distancia_2, ruta_2))

        if len(rutas_validas) == 0:
            return []

        rutas_validas.sort(key=lambda x: x[0])
        return rutas_validas[0][1]

    def longitud_ruta(self, ruta):
        total = 0.0

        for i in range(1, len(ruta)):
            p1 = ruta[i - 1]
            p2 = ruta[i]

            total += np.sqrt(
                (p2[0] - p1[0]) ** 2 +
                (p2[1] - p1[1]) ** 2
            )

        return total

    def calcular_ruta(self, start, goal):
        if not self.es_valido(goal[0], goal[1]):
            print("[RUTA] El destino no es válido porque cae dentro de un obstáculo.")
            return []

        ruta_l = self.calcular_ruta_l(start, goal)

        if len(ruta_l) > 0:
            print("[RUTA] Ruta en L encontrada:")
            for punto in ruta_l:
                print(f"       ({punto[0]:.0f}, {punto[1]:.0f})")
            return ruta_l

        print("[RUTA] No se puede hacer una L directa. Usando A* sin diagonales...")
        return self.calcular_a_estrella(start, goal)

    def simplificar_ruta(self, camino):
        if len(camino) < 3:
            return camino

        camino_simplificado = [camino[0]]

        for i in range(1, len(camino) - 1):
            p_ant = camino_simplificado[-1]
            p_act = camino[i]
            p_sig = camino[i + 1]

            ang1 = np.arctan2(p_act[1] - p_ant[1], p_act[0] - p_ant[0])
            ang2 = np.arctan2(p_sig[1] - p_act[1], p_sig[0] - p_act[0])

            if abs(ang1 - ang2) > 0.01:
                camino_simplificado.append(p_act)

        camino_simplificado.append(camino[-1])

        return camino_simplificado

    def calcular_a_estrella(self, start, goal):
        paso = 50

        start = (
            round(start[0] / paso) * paso,
            round(start[1] / paso) * paso
        )

        goal = (
            round(goal[0] / paso) * paso,
            round(goal[1] / paso) * paso
        )

        frontera = []
        heapq.heappush(frontera, (0, start))

        vinieron_de = {start: None}
        coste_hasta = {start: 0}

        movimientos = [
            (paso, 0),
            (-paso, 0),
            (0, paso),
            (0, -paso)
        ]

        encontrado = False

        while frontera:
            actual = heapq.heappop(frontera)[1]

            if actual == goal:
                encontrado = True
                break

            for mov in movimientos:
                siguiente = (
                    actual[0] + mov[0],
                    actual[1] + mov[1]
                )

                coste_nuevo = coste_hasta[actual] + paso

                if self.es_valido(siguiente[0], siguiente[1]):
                    if siguiente not in coste_hasta or coste_nuevo < coste_hasta[siguiente]:
                        coste_hasta[siguiente] = coste_nuevo

                        prioridad = coste_nuevo + abs(goal[0] - siguiente[0]) + abs(goal[1] - siguiente[1])

                        heapq.heappush(frontera, (prioridad, siguiente))
                        vinieron_de[siguiente] = actual

        if not encontrado:
            print("[RUTA] No se ha encontrado ruta hasta el centro del almacén.")
            return []

        camino = []
        actual = goal

        while actual is not None:
            camino.append(actual)
            actual = vinieron_de.get(actual)

        camino.reverse()
        camino = self.simplificar_ruta(camino)

        print(f"[RUTA] Ruta A* sin diagonales, puntos: {len(camino)}")
        for punto in camino:
            print(f"       {punto}")

        return camino

    def enviar_comando_arduino(self, comando):
        if self.arduino is not None and self.arduino.is_open:
            try:
                self.arduino.write(comando.encode("utf-8"))
                print(f"Enviando robot: {comando}")

                inicio_tiempo = time.time()

                while True:
                    self.fig.canvas.flush_events()
                    plt.pause(0.001)

                    if self.arduino.in_waiting > 0:
                        respuesta = self.arduino.readline().decode("utf-8", errors="ignore").strip()

                        if respuesta.startswith("OK_"):
                            print(f"Arduino robot dice: {respuesta}")
                            break

                        elif respuesta != "":
                            print(f"Arduino robot log: {respuesta}")

                    if time.time() - inicio_tiempo > 90:
                        print("[SISTEMA] Alerta: tiempo de espera agotado 90s.")
                        break

            except Exception as e:
                print(f"[SISTEMA] Error en comunicación con robot: {e}")

        else:
            print(f"[SISTEMA] Modo visual. No se envía a Arduino robot: {comando}")
            time.sleep(0.1)

    def enviar_comando_servo(self, comando):
        if self.arduino is not None and self.arduino.is_open:
            try:
                texto = f"{comando}\n"

                self.arduino.write(texto.encode("utf-8"))
                print(f"[SERVO] Enviando al Arduino principal: {texto.strip()}")

                inicio = time.time()

                while time.time() - inicio < 5.0:
                    self.fig.canvas.flush_events()
                    plt.pause(0.001)

                    if self.arduino.in_waiting > 0:
                        respuesta = self.arduino.readline().decode("utf-8", errors="ignore").strip()

                        if respuesta != "":
                            print(f"[SERVO] Arduino dice: {respuesta}")

                        if respuesta == "CELEBRAR_FIN" or respuesta.startswith("OK_SERVO"):
                            break

            except Exception as e:
                print(f"[SERVO] Error enviando comando al servo: {e}")

        else:
            print(f"[SERVO] Arduino no conectado. No se envía: {comando}")
            time.sleep(0.1)

    def enviar_giro_suave(self, giro_total):
        if abs(giro_total) <= self.max_giro_suave_almacen_7_grados:
            self.enviar_comando_arduino(f"<G:{giro_total:.1f}>")
            return

        signo = 1 if giro_total > 0 else -1
        giro_restante = abs(giro_total)

        while giro_restante > 0:
            giro_parcial = min(self.max_giro_suave_almacen_7_grados, giro_restante)
            giro_parcial *= signo

            print(f"[GIRO SUAVE] Enviando giro parcial: {giro_parcial:.1f} grados")
            self.enviar_comando_arduino(f"<G:{giro_parcial:.1f}>")

            giro_restante -= abs(giro_parcial)
            time.sleep(self.pausa_giro_suave_almacen_7_s)

    def actualizar_visual_avance(self, distancia_mm):
        self.robot_x += distancia_mm * np.cos(np.radians(self.robot_theta))
        self.robot_y += distancia_mm * np.sin(np.radians(self.robot_theta))

        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()
        plt.pause(0.01)

    def reducir_giro_por_grados(self, giro, grados_a_restar):
        if abs(giro) <= grados_a_restar:
            return 0.0

        if giro > 0:
            return giro - grados_a_restar

        return giro + grados_a_restar

    def aplicar_maniobra_primer_giro_almacen_3(self):
        if self.almacen_destino_actual != "3":
            return False

        if self.maniobra_primer_giro_almacen_3_hecha:
            return False

        print("[AJUSTE] Maniobra especial sustituyendo el primer giro del almacén 3")

        print(f"[AJUSTE] Retroceso inicial almacén 3: {self.retroceso_primer_giro_almacen_3_mm:.1f} mm")
        self.enviar_comando_arduino(f"<A:{-self.retroceso_primer_giro_almacen_3_mm:.1f}>")
        self.actualizar_visual_avance(-self.retroceso_primer_giro_almacen_3_mm)

        print(f"[AJUSTE] Giro suave a la derecha almacén 3: {self.giro_derecha_primer_giro_almacen_3_grados:.1f} grados")
        self.enviar_comando_arduino(f"<G:{self.giro_derecha_primer_giro_almacen_3_grados:.1f}>")

        self.ultimo_giro_enviado = self.giro_derecha_primer_giro_almacen_3_grados
        self.robot_theta += self.giro_derecha_primer_giro_almacen_3_grados
        self.robot_theta = self.robot_theta % 360

        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()
        plt.pause(0.01)

        self.maniobra_primer_giro_almacen_3_hecha = True

        return True

    def aplicar_ajuste_final(self):
        if self.modo_termometro:
            return

        if self.almacen_destino_actual == "1":
            print(f"[AJUSTE] Retroceso final almacén 1: {self.retroceso_final_almacen_1_mm:.1f} mm")
            self.enviar_comando_arduino(f"<A:{-self.retroceso_final_almacen_1_mm:.1f}>")
            self.actualizar_visual_avance(-self.retroceso_final_almacen_1_mm)

        elif self.almacen_destino_actual == "3":
            print("[AJUSTE] Ajuste final almacén 3")

            if abs(self.ultimo_giro_enviado) > 1.0:
                signo_inverso = -1 if self.ultimo_giro_enviado > 0 else 1
                giro_inverso = signo_inverso * self.giro_final_inverso_almacen_3_grados

                print(f"[AJUSTE] Giro inverso final almacén 3: {giro_inverso:.1f} grados")
                self.enviar_comando_arduino(f"<G:{giro_inverso:.1f}>")

                self.robot_theta += giro_inverso
                self.robot_theta = self.robot_theta % 360

                self.configurar_mapa()
                self.dibujar_robot()
                plt.draw()
                plt.pause(0.01)

            print(f"[AJUSTE] Retroceso final almacén 3: {self.retroceso_final_almacen_3_mm:.1f} mm")
            self.enviar_comando_arduino(f"<A:{-self.retroceso_final_almacen_3_mm:.1f}>")
            self.actualizar_visual_avance(-self.retroceso_final_almacen_3_mm)

            self.ultimo_almacen_visitado = "3"

        elif self.almacen_destino_actual == "4" and self.ruta_almacen_4_desde_inicio:
            print(f"[AJUSTE ALMACÉN 4] Retroceso final desde inicio: {self.retroceso_final_almacen_4_inicio_mm:.1f} mm")
            self.enviar_comando_arduino(f"<A:{-self.retroceso_final_almacen_4_inicio_mm:.1f}>")
            self.actualizar_visual_avance(-self.retroceso_final_almacen_4_inicio_mm)

        elif self.almacen_destino_actual == "5" and self.ruta_almacen_5_desde_inicio:
            print(f"[AJUSTE ALMACÉN 5] Retroceso final desde inicio: {self.retroceso_final_almacen_5_inicio_mm:.1f} mm")
            self.enviar_comando_arduino(f"<A:{-self.retroceso_final_almacen_5_inicio_mm:.1f}>")
            self.actualizar_visual_avance(-self.retroceso_final_almacen_5_inicio_mm)

        elif self.almacen_destino_actual == "7" and self.ruta_almacen_7_desde_inicio:
            self.aplicar_ajuste_final_almacen_7()

        elif self.almacen_destino_actual == "8":
            print(f"[AJUSTE] Avance final almacén 8: {self.avance_final_almacen_8_mm:.1f} mm")
            self.enviar_comando_arduino(f"<A:{self.avance_final_almacen_8_mm:.1f}>")
            self.actualizar_visual_avance(self.avance_final_almacen_8_mm)

    def aplicar_ajuste_final_almacen_7(self):
        if self.ajuste_final_almacen_7_hecho:
            return

        print("[AJUSTE ALMACÉN 7] Después de la ruta: giro inverso y avance corto.")
        print(f"[AJUSTE ALMACÉN 7] Giro inverso final: {self.giro_final_izquierda_almacen_7_inicio_grados:.1f} grados")

        self.enviar_comando_arduino(f"<G:{self.giro_final_izquierda_almacen_7_inicio_grados:.1f}>")

        self.robot_theta += self.giro_final_izquierda_almacen_7_inicio_grados
        self.robot_theta = self.robot_theta % 360

        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()
        plt.pause(0.01)

        print(f"[AJUSTE ALMACÉN 7] Avance corto: {self.avance_final_almacen_7_inicio_mm:.1f} mm")

        self.enviar_comando_arduino(f"<A:{self.avance_final_almacen_7_inicio_mm:.1f}>")
        self.actualizar_visual_avance(self.avance_final_almacen_7_inicio_mm)

        self.ajuste_final_almacen_7_hecho = True

    def calcular_iteraciones_avance(self, num_tramos):
        if self.almacen_destino_actual != "8":
            return num_tramos, 1.0

        self.contador_avances_almacen_8 += 1

        if self.contador_avances_almacen_8 == 1:
            iteraciones = max(1, num_tramos - self.quitar_interacciones_almacen_8)

            print(
                f"[AJUSTE ALMACÉN 8] Primer avance: "
                f"tramos calculados = {num_tramos}, tramos enviados = {iteraciones}"
            )

            return iteraciones, 1.0

        if self.contador_avances_almacen_8 == 2:
            print(
                f"[AJUSTE ALMACÉN 8] Avance después del giro: "
                f"se enviarán {self.interacciones_despues_giro_almacen_8} interacciones"
            )

            return 1, self.interacciones_despues_giro_almacen_8

        return num_tramos, 1.0

    def ejecutar_ruta_especial_3_a_4(self):
        print("\n--- RUTA ESPECIAL 3 -> 4 ---")
        print("[RUTA ESPECIAL] Giro fijo a la derecha: -90.0 grados")

        self.enviar_comando_arduino("<G:-90.0>")

        self.robot_theta -= 90.0
        self.robot_theta = self.robot_theta % 360

        punto_actual = self.ruta_completa[0]
        punto_destino = self.ruta_completa[1]

        distancia = np.sqrt(
            (punto_destino[0] - punto_actual[0]) ** 2 +
            (punto_destino[1] - punto_actual[1]) ** 2
        )

        distancia_enviada = distancia * self.factor_avance_3_a_4

        print(
            f"[RUTA ESPECIAL] Avance recto calculado: {distancia:.1f} mm | "
            f"Avance enviado: {distancia_enviada:.1f} mm"
        )

        self.enviar_comando_arduino(f"<A:{distancia_enviada:.1f}>")

        self.robot_x = punto_destino[0]
        self.robot_y = punto_destino[1]

        self.configurar_mapa()
        self.dibujar_robot()
        plt.draw()
        plt.pause(0.01)

        self.ultimo_almacen_visitado = "4"
        self.ruta_especial_3_a_4 = False

        self.mover_servo_fin_tarea()

        print("[ESTADO] Destino alcanzado.")

    def animar_movimiento(self):
        print("\n--- INICIANDO RUTA FÍSICA ---")

        if self.arduino is not None and self.arduino.is_open:
            self.arduino.reset_input_buffer()
            self.arduino.reset_output_buffer()

        if self.ruta_especial_3_a_4:
            self.ejecutar_ruta_especial_3_a_4()
            return

        for i in range(1, len(self.ruta_completa)):
            punto_actual = self.ruta_completa[i - 1]
            punto_siguiente = self.ruta_completa[i]

            distancia = np.sqrt(
                (punto_siguiente[0] - punto_actual[0]) ** 2 +
                (punto_siguiente[1] - punto_actual[1]) ** 2
            )

            if distancia > 0:
                nuevo_angulo = np.degrees(
                    np.arctan2(
                        punto_siguiente[1] - punto_actual[1],
                        punto_siguiente[0] - punto_actual[0]
                    )
                )

                if nuevo_angulo < 0:
                    nuevo_angulo += 360

                diferencia_angulo = nuevo_angulo - self.robot_theta
                diferencia_angulo = (diferencia_angulo + 180) % 360 - 180

                if abs(diferencia_angulo) > 1.0:
                    if self.almacen_destino_actual == "3" and not self.maniobra_primer_giro_almacen_3_hecha:
                        self.aplicar_maniobra_primer_giro_almacen_3()
                        self.robot_theta = nuevo_angulo

                    else:
                        if self.almacen_destino_actual == "1":
                            giro_corregido = diferencia_angulo * self.factor_giro_almacen_1

                        elif self.almacen_destino_actual == "8":
                            giro_corregido = diferencia_angulo * self.factor_giro_almacen_8

                        elif self.ruta_almacen_4_desde_inicio and self.almacen_destino_actual == "4":
                            giro_corregido = self.reducir_giro_por_grados(
                                diferencia_angulo,
                                self.restar_giro_almacen_4_inicio_grados
                            )

                        elif self.ruta_almacen_5_desde_inicio and self.almacen_destino_actual == "5":
                            giro_corregido = self.reducir_giro_por_grados(
                                diferencia_angulo,
                                self.restar_giro_almacen_5_inicio_grados
                            )

                        elif self.ruta_almacen_6_desde_inicio and self.almacen_destino_actual == "6":
                            giro_corregido = self.reducir_giro_por_grados(
                                diferencia_angulo,
                                self.restar_giro_almacen_6_inicio_grados
                            )

                        elif self.ruta_almacen_7_desde_inicio and self.almacen_destino_actual == "7":
                            giro_corregido = self.reducir_giro_por_grados(
                                diferencia_angulo,
                                self.restar_giro_almacen_7_inicio_grados
                            )

                        elif self.ruta_almacen_9_desde_inicio and self.almacen_destino_actual == "9":
                            giro_corregido = diferencia_angulo * self.factor_giro_almacen_9_inicio

                        elif self.ruta_almacen_10_desde_inicio and self.almacen_destino_actual == "10":
                            giro_corregido = self.reducir_giro_por_grados(
                                diferencia_angulo,
                                self.restar_giro_almacen_10_inicio_grados
                            )

                        else:
                            giro_corregido = diferencia_angulo * self.factor_giro

                        print(
                            f"[GIRO] Giro calculado: {diferencia_angulo:.1f} grados | "
                            f"Giro enviado: {giro_corregido:.1f} grados"
                        )

                        if (
                            self.ruta_almacen_7_desde_inicio
                            and self.almacen_destino_actual == "7"
                            and not self.primer_giro_almacen_7_hecho
                        ):
                            print("[AJUSTE ALMACÉN 7] Primer giro suavizado en varios giros pequeños.")
                            self.enviar_giro_suave(giro_corregido)
                            self.primer_giro_almacen_7_hecho = True
                        else:
                            self.enviar_comando_arduino(f"<G:{giro_corregido:.1f}>")

                        self.ultimo_giro_enviado = giro_corregido
                        self.robot_theta = nuevo_angulo

                num_tramos = max(1, int(np.ceil(distancia / self.max_tramo_mm)))
                iteraciones_envio, multiplicador_interaccion = self.calcular_iteraciones_avance(num_tramos)

                if (
                    self.ruta_almacen_9_desde_inicio
                    and self.almacen_destino_actual == "9"
                    and i == 1
                    and len(self.ruta_completa) >= 3
                ):
                    iteraciones_envio = max(1, iteraciones_envio - 1)

                if (
                    self.ruta_almacen_10_desde_inicio
                    and self.almacen_destino_actual == "10"
                    and i == 1
                    and len(self.ruta_completa) >= 3
                ):
                    iteraciones_envio = max(1, iteraciones_envio - 1)

                dx = (punto_siguiente[0] - punto_actual[0]) / num_tramos
                dy = (punto_siguiente[1] - punto_actual[1]) / num_tramos

                distancia_parcial = distancia / num_tramos
                distancia_enviada_base = distancia_parcial * self.factor_avance * multiplicador_interaccion

                for indice_interaccion in range(iteraciones_envio):
                    distancia_enviada = distancia_enviada_base
                    factor_visual = 1.0
                    usar_visual_por_orientacion = False

                    if (
                        self.almacen_destino_actual == "2"
                        and i == len(self.ruta_completa) - 1
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_almacen_2
                        factor_visual = self.factor_ultima_interaccion_almacen_2

                    if (
                        self.ruta_almacen_4_desde_inicio
                        and self.almacen_destino_actual == "4"
                        and i == 1
                        and len(self.ruta_completa) >= 3
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_antes_giro_almacen_4_inicio
                        factor_visual = self.factor_ultima_interaccion_antes_giro_almacen_4_inicio

                    if (
                        self.ruta_almacen_5_desde_inicio
                        and self.almacen_destino_actual == "5"
                        and i == 1
                        and len(self.ruta_completa) >= 3
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_antes_giro_almacen_5_inicio
                        factor_visual = self.factor_ultima_interaccion_antes_giro_almacen_5_inicio

                    if (
                        self.ruta_almacen_6_desde_inicio
                        and self.almacen_destino_actual == "6"
                        and i == 1
                        and len(self.ruta_completa) >= 3
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_antes_giro_almacen_6_inicio
                        factor_visual = self.factor_ultima_interaccion_antes_giro_almacen_6_inicio

                    if (
                        self.ruta_almacen_7_desde_inicio
                        and self.almacen_destino_actual == "7"
                        and i == 1
                        and len(self.ruta_completa) >= 3
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_antes_giro_almacen_7_inicio
                        factor_visual = self.factor_ultima_interaccion_antes_giro_almacen_7_inicio

                    if (
                        self.ruta_almacen_5_desde_inicio
                        and self.almacen_destino_actual == "5"
                        and i == len(self.ruta_completa) - 1
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_almacen_5_inicio
                        factor_visual = self.factor_ultima_interaccion_almacen_5_inicio

                    if (
                        self.ruta_almacen_6_desde_inicio
                        and self.almacen_destino_actual == "6"
                        and i == len(self.ruta_completa) - 1
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_almacen_6_inicio
                        factor_visual = self.factor_ultima_interaccion_almacen_6_inicio

                    if (
                        self.ruta_almacen_7_desde_inicio
                        and self.almacen_destino_actual == "7"
                        and i == len(self.ruta_completa) - 1
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        print("[AJUSTE ALMACÉN 7] Última interacción eliminada.")
                        continue

                    if (
                        self.ruta_almacen_9_desde_inicio
                        and self.almacen_destino_actual == "9"
                        and i == len(self.ruta_completa) - 1
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_despues_giro_almacen_9_inicio
                        factor_visual = self.factor_ultima_interaccion_despues_giro_almacen_9_inicio

                    if (
                        self.ruta_almacen_10_desde_inicio
                        and self.almacen_destino_actual == "10"
                        and i == len(self.ruta_completa) - 1
                        and indice_interaccion == iteraciones_envio - 1
                    ):
                        distancia_enviada *= self.factor_ultima_interaccion_almacen_10_inicio
                        factor_visual = self.factor_ultima_interaccion_almacen_10_inicio

                    print(
                        f"[AVANCE] Distancia calculada: {distancia_parcial:.1f} mm | "
                        f"Distancia enviada: {distancia_enviada:.1f} mm"
                    )

                    self.enviar_comando_arduino(f"<A:{distancia_enviada:.1f}>")

                    if usar_visual_por_orientacion:
                        self.actualizar_visual_avance(distancia_enviada)
                    else:
                        self.robot_x += dx * factor_visual
                        self.robot_y += dy * factor_visual

                        self.configurar_mapa()
                        self.dibujar_robot()

                        plt.draw()
                        plt.pause(0.01)

                continue

            self.robot_x, self.robot_y = punto_siguiente

            self.configurar_mapa()
            self.dibujar_robot()

            plt.draw()
            plt.pause(0.01)

        self.aplicar_ajuste_final()

        if self.almacen_destino_actual != "3":
            self.ultimo_almacen_visitado = self.almacen_destino_actual

        self.mover_servo_fin_tarea()

        print("[ESTADO] Destino alcanzado.")

    def iniciar(self):
        plt.show()


if __name__ == "__main__":
    sim = SimuladorEurobot()
    sim.iniciar()