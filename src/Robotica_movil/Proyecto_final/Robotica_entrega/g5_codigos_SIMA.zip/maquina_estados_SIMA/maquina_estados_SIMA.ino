#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>

#define BT_SERIAL Serial2

const float RT = 100.1f;
const float RPM_MAX = 410.0f;
float kp = 1.2255f;
float ki = 4.2745f;
float kd = 0.005f;

const int PPR = 12;
const float R_RI = 2.0f;
const float R_RD = 2.0f;
const float L = 10.0f;

float max_Vel = 2.0f * PI * RPM_MAX / 60.0f * R_RI;
float max_Acel = 27.0f;

// Pines motores
const int motorIzqPin1 = 7;
const int motorIzqPin2 = 8;
const int motorIzqPWM  = 10;

const int motorDerPin1 = 2;
const int motorDerPin2 = 4;
const int motorDerPWM  = 9;

// Servo SIN Servo.h
const int pinServo = 11;

const int SERVO_ANGULO_INICIO = 0;
const int SERVO_ANGULO_FINAL = 90;

const int SERVO_PULSO_MIN_US = 500;
const int SERVO_PULSO_MAX_US = 2500;
const int SERVO_PERIODO_US = 20000;

const unsigned long SERVO_TIEMPO_POSICION_MS = 400;
const int SERVO_REPETICIONES_CELEBRACION = 3;

int anguloServoActual = 0;

// Encoders
const byte encoder_MI_pinA = 39;
const byte encoder_MI_pinB = 38;
const byte encoder_MD_pinA = 29;
const byte encoder_MD_pinB = 28;

volatile long encoder_MI_cuenta = 0;
volatile long encoder_MD_cuenta = 0;

volatile int encoder_MI_ultimoCodificado = 0;
volatile int encoder_MD_ultimoCodificado = 0;

volatile long encoder_MI_cuentaAnterior = 0;
volatile long encoder_MD_cuentaAnterior = 0;

unsigned long encoder_MI_ultimaMedicion = 0;
unsigned long encoder_MD_ultimaMedicion = 0;

Adafruit_BNO055 bno(55, 0x28);

// Variables control velocidad
float RPM_RI_medidas = 0.0f;
float RPM_RD_medidas = 0.0f;

float RPM_RI_objetivo = 0.0f;
float RPM_RD_objetivo = 0.0f;

// Variables movimiento
float S = 0.0f;
float O = 0.0f;

float s = 0.0f;
float o = 0.0f;

float Distancia = 0.0f;
float Angulo = 0.0f;
float Angulo_ini = 0.0f;
float Ori_mant = 0.0f;

float T_INI_mov = 0.0f;
float tiempo = 0.0f;

float V_Obj = 0.0f;
float W_Obj = 0.0f;

float kp_pos_l = 3.0f;
float kp_ang_l = 2.0f;
float kp_ang_l_a = 5.0f;

const unsigned long DT_PID_US  = 10000;
const unsigned long DT_CTRL_MS = 30;

unsigned long t_pid = 0;
unsigned long t_ctrl = 0;
unsigned long t_inicio_comando = 0;

// Comunicación
String tramaRecibida = "";
bool comandoListo = false;

String tramaRecibidaUSB = "";
bool comandoListoUSB = false;

enum EstadoRobot {
  ESPERANDO,
  AVANZANDO,
  GIRANDO
};

EstadoRobot estadoActual = ESPERANDO;

void responderTodo(const String &mensaje) {
  BT_SERIAL.println(mensaje);
  Serial.println(mensaje);
}

void MotorIzquierdo(float Velocidad) {
  Velocidad = constrain(Velocidad, -100.0f, 100.0f);
  uint8_t pwmVal = map(abs(Velocidad), 0, 100, 0, 255);

  if (Velocidad > 0) {
    digitalWrite(motorIzqPin1, HIGH);
    digitalWrite(motorIzqPin2, LOW);
  } else if (Velocidad < 0) {
    digitalWrite(motorIzqPin1, LOW);
    digitalWrite(motorIzqPin2, HIGH);
  } else {
    digitalWrite(motorIzqPin1, LOW);
    digitalWrite(motorIzqPin2, LOW);
  }

  analogWrite(motorIzqPWM, pwmVal);
}

void MotorDerecho(float Velocidad) {
  Velocidad = constrain(Velocidad, -100.0f, 100.0f);
  uint8_t pwmVal = map(abs(Velocidad), 0, 100, 0, 255);

  if (Velocidad > 0) {
    digitalWrite(motorDerPin1, HIGH);
    digitalWrite(motorDerPin2, LOW);
  } else if (Velocidad < 0) {
    digitalWrite(motorDerPin1, LOW);
    digitalWrite(motorDerPin2, HIGH);
  } else {
    digitalWrite(motorDerPin1, LOW);
    digitalWrite(motorDerPin2, LOW);
  }

  analogWrite(motorDerPWM, pwmVal);
}

void PararMotores() {
  RPM_RI_objetivo = 0.0f;
  RPM_RD_objetivo = 0.0f;

  MotorIzquierdo(0);
  MotorDerecho(0);
}

// =======================================================
// SERVO MANUAL SIN Servo.h
// =======================================================

void enviarPulsoServoManual(int angulo) {
  angulo = constrain(angulo, 0, 180);

  int anchoPulso = map(angulo, 0, 180, SERVO_PULSO_MIN_US, SERVO_PULSO_MAX_US);

  digitalWrite(pinServo, HIGH);
  delayMicroseconds(anchoPulso);

  digitalWrite(pinServo, LOW);
  delayMicroseconds(SERVO_PERIODO_US - anchoPulso);
}

void moverServoManual(int angulo, unsigned long tiempoMs) {
  angulo = constrain(angulo, 0, 180);

  unsigned long inicio = millis();

  while (millis() - inicio < tiempoMs) {
    enviarPulsoServoManual(angulo);
  }

  anguloServoActual = angulo;

  BT_SERIAL.print("SERVO:");
  BT_SERIAL.println(anguloServoActual);

  Serial.print("SERVO:");
  Serial.println(anguloServoActual);
}

void moverServo(int angulo) {
  if (estadoActual != ESPERANDO) {
    responderTodo("BUSY_SERVO");
    return;
  }

  if (angulo < 0 || angulo > 180) {
    responderTodo("ERROR_SERVO");
    return;
  }

  PararMotores();
  moverServoManual(angulo, SERVO_TIEMPO_POSICION_MS);

  responderTodo("OK_SERVO:" + String(anguloServoActual));
}

void celebrarServo() {
  if (estadoActual != ESPERANDO) {
    responderTodo("BUSY_SERVO");
    return;
  }

  PararMotores();

  responderTodo("CELEBRAR_INICIO");

  // Siempre empieza en 0 grados
  moverServoManual(SERVO_ANGULO_INICIO, SERVO_TIEMPO_POSICION_MS);

  for (int i = 0; i < SERVO_REPETICIONES_CELEBRACION; i++) {
    moverServoManual(SERVO_ANGULO_FINAL, SERVO_TIEMPO_POSICION_MS);

    // Solo vuelve a 0 si no es la última repetición.
    // Así siempre acaba en 90 grados.
    if (i < SERVO_REPETICIONES_CELEBRACION - 1) {
      moverServoManual(SERVO_ANGULO_INICIO, SERVO_TIEMPO_POSICION_MS);
    }
  }

  // Seguridad: asegurar que acaba en 90 grados
  moverServoManual(SERVO_ANGULO_FINAL, SERVO_TIEMPO_POSICION_MS);

  responderTodo("CELEBRAR_FIN");
}

// =======================================================
// ENCODERS
// =======================================================

void contarEncoder_MI() {
  int faseA = digitalRead(encoder_MI_pinA);
  int faseB = digitalRead(encoder_MI_pinB);

  int codificadoActual = (faseA << 1) | faseB;
  int suma = (encoder_MI_ultimoCodificado << 2) | codificadoActual;

  switch (suma) {
    case 0b0001:
    case 0b0111:
    case 0b1110:
    case 0b1000:
      encoder_MI_cuenta--;
      break;

    case 0b0010:
    case 0b1011:
    case 0b1101:
    case 0b0100:
      encoder_MI_cuenta++;
      break;
  }

  encoder_MI_ultimoCodificado = codificadoActual;
}

void contarEncoder_MD() {
  int faseA = digitalRead(encoder_MD_pinA);
  int faseB = digitalRead(encoder_MD_pinB);

  int codificadoActual = (faseA << 1) | faseB;
  int suma = (encoder_MD_ultimoCodificado << 2) | codificadoActual;

  switch (suma) {
    case 0b0001:
    case 0b0111:
    case 0b1110:
    case 0b1000:
      encoder_MD_cuenta--;
      break;

    case 0b0010:
    case 0b1011:
    case 0b1101:
    case 0b0100:
      encoder_MD_cuenta++;
      break;
  }

  encoder_MD_ultimoCodificado = codificadoActual;
}

void establecerCuentaEncoder_MI(long valor) {
  noInterrupts();
  encoder_MI_cuenta = valor;
  encoder_MI_cuentaAnterior = valor;
  interrupts();
}

void establecerCuentaEncoder_MD(long valor) {
  noInterrupts();
  encoder_MD_cuenta = valor;
  encoder_MD_cuentaAnterior = valor;
  interrupts();
}

float calcularRPM_MI() {
  unsigned long tiempoActual = millis();
  unsigned long tiempoTranscurrido = tiempoActual - encoder_MI_ultimaMedicion;

  if (tiempoTranscurrido == 0) {
    return 0.0f;
  }

  long pulsosTranscurridos = encoder_MI_cuenta - encoder_MI_cuentaAnterior;
  float rpm = (pulsosTranscurridos * 60000.0f) / (PPR * tiempoTranscurrido);

  encoder_MI_cuentaAnterior = encoder_MI_cuenta;
  encoder_MI_ultimaMedicion = tiempoActual;

  return rpm;
}

float calcularRPM_MD() {
  unsigned long tiempoActual = millis();
  unsigned long tiempoTranscurrido = tiempoActual - encoder_MD_ultimaMedicion;

  if (tiempoTranscurrido == 0) {
    return 0.0f;
  }

  long pulsosTranscurridos = encoder_MD_cuenta - encoder_MD_cuentaAnterior;
  float rpm = (pulsosTranscurridos * 60000.0f) / (PPR * tiempoTranscurrido);

  encoder_MD_cuentaAnterior = encoder_MD_cuenta;
  encoder_MD_ultimaMedicion = tiempoActual;

  return rpm;
}

float calcularRPM_RI() {
  static float RPM_RI_Filt = 0.0f;
  static float RPM_RI_Prev = 0.0f;

  float RPM_RI = calcularRPM_MI() / RT;

  RPM_RI_Filt = 0.854f * RPM_RI_Filt + 0.0728f * (RPM_RI + RPM_RI_Prev);
  RPM_RI_Prev = RPM_RI;

  return RPM_RI_Filt;
}

float calcularRPM_RD() {
  static float RPM_RD_Filt = 0.0f;
  static float RPM_RD_Prev = 0.0f;

  float RPM_RD = calcularRPM_MD() / RT;

  RPM_RD_Filt = 0.854f * RPM_RD_Filt + 0.0728f * (RPM_RD + RPM_RD_Prev);
  RPM_RD_Prev = RPM_RD;

  return RPM_RD_Filt;
}

// =======================================================
// CONTROL DE MOTORES
// =======================================================

void RPM_IZQUIERDA(float RPM_RI, float RPM_MR_MAX) {
  RPM_RI = constrain(RPM_RI, -RPM_MR_MAX, RPM_MR_MAX);

  static float integral = 0.0f;
  static float errorPrev = 0.0f;
  static unsigned long prevUs = micros();

  unsigned long ahora = micros();
  float dt = (ahora - prevUs) / 1000000.0f;

  if (dt <= 0.0f) {
    dt = 0.000001f;
  }

  prevUs = ahora;

  float error = RPM_RI - RPM_RI_medidas;
  float integralNueva = integral + error * dt;
  float derivada = (error - errorPrev) / dt;
  float salida = kp * error + ki * integralNueva + kd * derivada;

  if (salida > 100.0f) {
    salida = 100.0f;
  } else if (salida < -100.0f) {
    salida = -100.0f;
  } else {
    integral = integralNueva;
  }

  errorPrev = error;

  if (abs(RPM_RI) < 0.1f) {
    MotorIzquierdo(0);
  } else {
    MotorIzquierdo(salida);
  }
}

void RPM_DERECHA(float RPM_RD, float RPM_MR_MAX) {
  RPM_RD = constrain(RPM_RD, -RPM_MR_MAX, RPM_MR_MAX);

  static float integral = 0.0f;
  static float errorPrev = 0.0f;
  static unsigned long prevUs = micros();

  unsigned long ahora = micros();
  float dt = (ahora - prevUs) / 1000000.0f;

  if (dt <= 0.0f) {
    dt = 0.000001f;
  }

  prevUs = ahora;

  float error = RPM_RD - RPM_RD_medidas;
  float integralNueva = integral + error * dt;
  float derivada = (error - errorPrev) / dt;
  float salida = kp * error + ki * integralNueva + kd * derivada;

  if (salida > 100.0f) {
    salida = 100.0f;
  } else if (salida < -100.0f) {
    salida = -100.0f;
  } else {
    integral = integralNueva;
  }

  errorPrev = error;

  if (abs(RPM_RD) < 0.1f) {
    MotorDerecho(0);
  } else {
    MotorDerecho(salida);
  }
}

void V_W_ROBOT(float V_lin, float V_ang, float &RPM_RI_Targ, float &RPM_RD_Targ) {
  float V_RI_Targ = V_lin - (V_ang * L / 2.0f);
  float V_RD_Targ = V_lin + (V_ang * L / 2.0f);

  RPM_RI_Targ = V_RI_Targ / (2.0f * PI * R_RI) * 60.0f;
  RPM_RD_Targ = V_RD_Targ / (2.0f * PI * R_RD) * 60.0f;
}

// =======================================================
// POSICIÓN / BNO055
// =======================================================

void actualizarPos(float &Distancia_R, float &Angulo_cont) {
  noInterrupts();
  long pulsos_I = encoder_MI_cuenta;
  long pulsos_D = encoder_MD_cuenta;
  interrupts();

  float Distancia_RI = pulsos_I * 2.0f * PI * R_RI / RT / PPR;
  float Distancia_RD = pulsos_D * 2.0f * PI * R_RD / RT / PPR;

  Distancia_R = (Distancia_RI + Distancia_RD) / 2.0f;

  sensors_event_t orientationData;
  bno.getEvent(&orientationData, Adafruit_BNO055::VECTOR_EULER);

  static float vueltas = 0.0f;
  static bool primera = true;
  static float thetaPrev = 0.0f;

  float theta = 360.0f - orientationData.orientation.x;

  if (theta > 180.0f) {
    theta -= 360.0f;
  }

  if (primera) {
    thetaPrev = theta;
    primera = false;
  }

  if ((thetaPrev - theta) > 270.0f) {
    vueltas += 1.0f;
  }

  if ((thetaPrev - theta) < -270.0f) {
    vueltas -= 1.0f;
  }

  thetaPrev = theta;

  Angulo_cont = (vueltas * 360.0f + theta) * PI / 180.0f;
}

// =======================================================
// PERFIL DE MOVIMIENTO
// =======================================================

float Calcula_Desplazamiento(float S_obj, float t) {
  float T_Acel = 40.0f / 15.0f / sqrt(3.0f) * max_Vel / max_Acel;
  float l_ad = 16.0f / 15.0f * T_Acel * max_Vel;
  float T_cte = (abs(S_obj) - l_ad) / max_Vel;
  float T_Acel_v = sqrt(5.0f / 2.0f / sqrt(3.0f) * abs(S_obj) / max_Acel);

  float salida = 0.0f;

  if (T_cte > 0.0f) {
    if (t <= T_Acel) {
      salida = l_ad * (
        10.0f * pow(t / (2.0f * T_Acel), 3.0f)
        - 15.0f * pow(t / (2.0f * T_Acel), 4.0f)
        + 6.0f * pow(t / (2.0f * T_Acel), 5.0f)
      );
    } else if (t <= T_Acel + T_cte) {
      salida = l_ad / 2.0f + l_ad / (2.0f * T_Acel) * (15.0f / 8.0f) * (t - T_Acel);
    } else if (t <= T_Acel + T_cte + T_Acel) {
      salida =
        l_ad / (2.0f * T_Acel) * (15.0f / 8.0f) * T_cte
        + l_ad * (
          10.0f * pow((t - T_cte) / (2.0f * T_Acel), 3.0f)
          - 15.0f * pow((t - T_cte) / (2.0f * T_Acel), 4.0f)
          + 6.0f * pow((t - T_cte) / (2.0f * T_Acel), 5.0f)
        );
    } else {
      salida = abs(S_obj);
    }
  } else {
    if (t <= 2.0f * T_Acel_v) {
      salida = abs(S_obj) * (
        10.0f * pow(t / (2.0f * T_Acel_v), 3.0f)
        - 15.0f * pow(t / (2.0f * T_Acel_v), 4.0f)
        + 6.0f * pow(t / (2.0f * T_Acel_v), 5.0f)
      );
    } else {
      salida = abs(S_obj);
    }
  }

  if (S_obj < 0.0f) {
    salida = -salida;
  }

  return salida;
}

float Calcula_Rotacion(float O_obj, float t) {
  float S_O = O_obj * L / 2.0f;
  float s_o = Calcula_Desplazamiento(S_O, t);

  return s_o / (L / 2.0f);
}

// =======================================================
// COMUNICACIÓN
// =======================================================

void limpiarFinalLineaBluetooth() {
  while (BT_SERIAL.available() > 0) {
    char c = BT_SERIAL.peek();

    if (c == '\n' || c == '\r' || c == ' ') {
      BT_SERIAL.read();
    } else {
      break;
    }
  }
}

void limpiarFinalLineaUSB() {
  while (Serial.available() > 0) {
    char c = Serial.peek();

    if (c == '\n' || c == '\r' || c == ' ') {
      Serial.read();
    } else {
      break;
    }
  }
}

void leerBluetooth() {
  while (BT_SERIAL.available() > 0) {
    char c = BT_SERIAL.read();

    if (c == 'S' || c == 's') {
      int angulo = BT_SERIAL.parseInt();
      limpiarFinalLineaBluetooth();
      moverServo(angulo);
    }

    else if (c == 'C' || c == 'c') {
      limpiarFinalLineaBluetooth();
      celebrarServo();
    }

    else if (c == '<') {
      tramaRecibida = "";
    }

    else if (c == '>') {
      comandoListo = true;
    }

    else {
      tramaRecibida += c;
    }
  }
}

void leerUSB() {
  while (Serial.available() > 0) {
    char c = Serial.read();

    if (c == 'S' || c == 's') {
      int angulo = Serial.parseInt();
      limpiarFinalLineaUSB();
      moverServo(angulo);
    }

    else if (c == 'C' || c == 'c') {
      limpiarFinalLineaUSB();
      celebrarServo();
    }

    else if (c == '<') {
      tramaRecibidaUSB = "";
    }

    else if (c == '>') {
      comandoListoUSB = true;
    }

    else {
      tramaRecibidaUSB += c;
    }
  }
}

// =======================================================
// COMANDOS DEL ROBOT
// =======================================================

void iniciarAvance(float distanciaMm) {
  S = distanciaMm / 10.0f;

  T_INI_mov = micros() / 1000000.0f;
  tiempo = 0.0f;
  s = 0.0f;

  establecerCuentaEncoder_MI(0);
  establecerCuentaEncoder_MD(0);

  actualizarPos(Distancia, Angulo);

  Ori_mant = Angulo;
  t_inicio_comando = millis();
  estadoActual = AVANZANDO;

  BT_SERIAL.print("LOG_AVANCE_CM=");
  BT_SERIAL.println(S);

  Serial.print("LOG_AVANCE_CM=");
  Serial.println(S);
}

void iniciarGiro(float grados) {
  O = grados * PI / 180.0f;

  T_INI_mov = micros() / 1000000.0f;
  tiempo = 0.0f;
  o = 0.0f;

  establecerCuentaEncoder_MI(0);
  establecerCuentaEncoder_MD(0);

  actualizarPos(Distancia, Angulo);

  Angulo_ini = Angulo;
  t_inicio_comando = millis();
  estadoActual = GIRANDO;

  BT_SERIAL.print("LOG_GIRO_GRADOS=");
  BT_SERIAL.println(grados);

  Serial.print("LOG_GIRO_GRADOS=");
  Serial.println(grados);
}

void procesarTrama(String trama) {
  trama.trim();

  if (trama.length() == 0) {
    return;
  }

  char tipo = trama.charAt(0);

  if (tipo == 'C' || tipo == 'c') {
    celebrarServo();
    return;
  }

  if (trama.length() < 3) {
    return;
  }

  float valor = trama.substring(2).toFloat();

  if (tipo == 'A' || tipo == 'a') {
    iniciarAvance(valor);
  }

  else if (tipo == 'G' || tipo == 'g') {
    iniciarGiro(valor);
  }

  else if (tipo == 'S' || tipo == 's') {
    moverServo((int)valor);
  }
}

void procesarComando() {
  if (comandoListo) {
    comandoListo = false;

    String trama = tramaRecibida;
    tramaRecibida = "";

    procesarTrama(trama);
  }

  if (comandoListoUSB) {
    comandoListoUSB = false;

    String trama = tramaRecibidaUSB;
    tramaRecibidaUSB = "";

    procesarTrama(trama);
  }
}

// =======================================================
// SETUP / LOOP
// =======================================================

void setup() {
  pinMode(motorIzqPin1, OUTPUT);
  pinMode(motorIzqPin2, OUTPUT);
  pinMode(motorIzqPWM, OUTPUT);

  pinMode(motorDerPin1, OUTPUT);
  pinMode(motorDerPin2, OUTPUT);
  pinMode(motorDerPWM, OUTPUT);

  pinMode(pinServo, OUTPUT);
  digitalWrite(pinServo, LOW);

  PararMotores();

  pinMode(encoder_MI_pinA, INPUT_PULLUP);
  pinMode(encoder_MI_pinB, INPUT_PULLUP);
  pinMode(encoder_MD_pinA, INPUT_PULLUP);
  pinMode(encoder_MD_pinB, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(encoder_MI_pinA), contarEncoder_MI, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoder_MI_pinB), contarEncoder_MI, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoder_MD_pinA), contarEncoder_MD, CHANGE);
  attachInterrupt(digitalPinToInterrupt(encoder_MD_pinB), contarEncoder_MD, CHANGE);

  Serial.begin(115200);
  BT_SERIAL.begin(115200);
  BT_SERIAL.setTimeout(80);
  Serial.setTimeout(80);

  if (!bno.begin()) {
    responderTodo("ERROR_BNO055");

    while (1) {
      PararMotores();
      delay(100);
    }
  }

  delay(500);

  actualizarPos(Distancia, Angulo);

  // Posición inicial del servo: 0 grados.
  // No usamos Servo.h, solo pulsos manuales.
  moverServoManual(SERVO_ANGULO_INICIO, 500);

  responderTodo("ARDUINO_LISTO_SIMA_SERVO_MANUAL");
  responderTodo("COMANDOS_SERVO: S0 S90 C <S:90> <C>");
}

void loop() {
  leerBluetooth();
  leerUSB();

  if (estadoActual == ESPERANDO) {
    procesarComando();
  }

  unsigned long now_us = micros();

  if (now_us - t_pid >= DT_PID_US) {
    t_pid = now_us;

    RPM_RI_medidas = calcularRPM_RI();
    RPM_RD_medidas = calcularRPM_RD();

    RPM_IZQUIERDA(RPM_RI_objetivo, RPM_MAX);
    RPM_DERECHA(RPM_RD_objetivo, RPM_MAX);
  }

  unsigned long now_ms = millis();

  if (now_ms - t_ctrl < DT_CTRL_MS) {
    return;
  }

  t_ctrl = now_ms;

  actualizarPos(Distancia, Angulo);

  switch (estadoActual) {
    case ESPERANDO:
      PararMotores();
      break;

    case AVANZANDO: {
      tiempo = micros() / 1000000.0f - T_INI_mov;
      s = Calcula_Desplazamiento(S, tiempo);

      float error_pos = s - Distancia;
      float error_ang = Ori_mant - Angulo;

      V_Obj = kp_pos_l * error_pos;
      W_Obj = kp_ang_l * error_ang;

      V_W_ROBOT(V_Obj, W_Obj, RPM_RI_objetivo, RPM_RD_objetivo);

      bool perfilTerminado = abs(s) >= abs(S);
      bool timeout = millis() - t_inicio_comando > 90000UL;

      if (perfilTerminado || timeout) {
        PararMotores();
        estadoActual = ESPERANDO;
        responderTodo("OK_AVANCE");
      }
    } break;

    case GIRANDO: {
      tiempo = micros() / 1000000.0f - T_INI_mov;
      o = Calcula_Rotacion(O, tiempo);

      float error_ang = (Angulo_ini + o) - Angulo;

      W_Obj = kp_ang_l_a * error_ang;

      V_W_ROBOT(0.0f, W_Obj, RPM_RI_objetivo, RPM_RD_objetivo);

      bool perfilTerminado = abs(o) >= abs(O);
      bool timeout = millis() - t_inicio_comando > 90000UL;

      if (perfilTerminado || timeout) {
        PararMotores();
        estadoActual = ESPERANDO;
        responderTodo("OK_GIRO");
      }
    } break;
  }
}